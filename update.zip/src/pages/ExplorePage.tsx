import { useState } from "react";
import { useNavigate } from "react-router-dom";
import TopBar from "../components/TopBar";
import BottomNav from "../components/BottomNav";
import RegionArt from "../components/RegionArt";
import { REGIONS } from "../data/regions";
import { TAGS } from "../data/tags";
import type { TagKey } from "../types";
import { useApp } from "../store/AppContext";

export default function ExplorePage() {
  const navigate = useNavigate();
  const { user } = useApp();
  const [filter, setFilter] = useState<TagKey | "all">("all");

  const filtered = REGIONS.filter((r) => filter === "all" || r.tags.includes(filter));

  return (
    <>
      <TopBar title="둘러보기" />
      <div className="flex-1 overflow-y-auto pb-4">
        <div className="px-5 pt-1">
          <h2 className="text-[22px] font-extrabold tracking-tight">경상북도 15개 지역</h2>
          <p className="text-[13px] text-[var(--color-ink-soft)] mt-1 font-medium">
            지금까지 <span className="text-[var(--color-accent)] font-bold">{user.stamps.length}곳</span>을 만났어요
          </p>
        </div>
        <div className="flex gap-2 px-5 mt-4 overflow-x-auto scrollbar-thin pb-1">
          <button
            onClick={() => setFilter("all")}
            className={`px-4 py-2 rounded-2xl text-[13px] font-bold whitespace-nowrap tap ${
              filter === "all"
                ? "bg-[var(--color-accent)] text-white shadow-[0_6px_16px_-6px_rgba(49,130,246,0.5)]"
                : "bg-white text-[var(--color-ink-soft)] card-soft"
            }`}
          >
            전체
          </button>
          {TAGS.map((t) => (
            <button
              key={t.key}
              onClick={() => setFilter(t.key)}
              className={`px-4 py-2 rounded-2xl text-[13px] font-bold whitespace-nowrap tap ${
                filter === t.key
                  ? "bg-[var(--color-accent)] text-white shadow-[0_6px_16px_-6px_rgba(49,130,246,0.5)]"
                  : "bg-white text-[var(--color-ink-soft)] card-soft"
              }`}
            >
              {t.emoji} {t.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-3 px-5 mt-5">
          {filtered.map((r) => (
            <button
              key={r.id}
              onClick={() => navigate(`/region/${r.id}`)}
              className="text-left bg-white rounded-[22px] overflow-hidden card-soft tap"
            >
              <RegionArt region={r} className="h-24" label={false} />
              <div className="p-3">
                <div className="flex items-center gap-1.5">
                  <p className="text-[14px] font-bold">{r.name}</p>
                  {user.stamps.includes(r.id) && (
                    <span className="text-[10px] font-bold text-[var(--color-mint)]">✓</span>
                  )}
                </div>
                <p className="text-[11px] text-[var(--color-ink-soft)] mt-0.5 line-clamp-2 leading-snug">
                  {r.summary}
                </p>
              </div>
            </button>
          ))}
        </div>
      </div>
      <BottomNav />
    </>
  );
}
