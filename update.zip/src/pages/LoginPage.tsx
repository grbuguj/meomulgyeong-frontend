import { useNavigate } from "react-router-dom";
import { useApp } from "../store/AppContext";

const SOCIAL_BUTTONS: { key: "google" | "kakao" | "naver"; label: string; bg: string; text: string; border?: string }[] = [
  { key: "kakao", label: "카카오로 시작하기", bg: "#FEE500", text: "#391B1B" },
  { key: "naver", label: "네이버로 시작하기", bg: "#03C75A", text: "#FFFFFF" },
  { key: "google", label: "Google로 시작하기", bg: "#FFFFFF", text: "#3C3C3C", border: "1px solid #ECEAE3" },
];

export default function LoginPage() {
  const { login } = useApp();
  const navigate = useNavigate();

  const handleLogin = (provider: "google" | "kakao" | "naver") => {
    login(provider);
    navigate("/onboarding");
  };

  return (
    <div className="flex-1 flex flex-col justify-between px-7 py-12">
      <div className="mt-14 text-center">
        <p className="text-[13px] font-bold text-[var(--color-accent)] mb-3">
          경상북도 인구감소지역 체류형 여행
        </p>
        <h1 className="text-[38px] font-extrabold text-[var(--color-ink)] tracking-tight leading-none">
          머물;경<span className="text-xl align-top ml-0.5">慶</span>
        </h1>
        <p className="text-[14px] text-[var(--color-ink-soft)] mt-4 leading-relaxed font-medium">
          잠깐 다녀오는 게 아니라, 여행은 여행.
          <br />
          경상북도 15개 인구감소지역에서.
        </p>
      </div>

      <div className="flex justify-center">
        <div
          className="w-36 h-36 rounded-[36px] flex items-center justify-center card-soft-lg"
          style={{ background: "linear-gradient(150deg, var(--color-accent-soft), #ffffff)" }}
        >
          <span className="text-6xl">🏯</span>
        </div>
      </div>

      <div className="space-y-2.5">
        {SOCIAL_BUTTONS.map((btn) => (
          <button
            key={btn.key}
            onClick={() => handleLogin(btn.key)}
            className="w-full py-4 rounded-2xl font-bold text-[14px] tap card-soft"
            style={{ background: btn.bg, color: btn.text, border: btn.border }}
          >
            {btn.label}
          </button>
        ))}
        <p className="text-center text-[11px] text-[var(--color-ink-faint)] pt-2 font-medium">
          로그인 시 서비스 이용약관 및 개인정보처리방침에 동의하게 됩니다
        </p>
      </div>
    </div>
  );
}
