import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useApp } from "../store/AppContext";
import Button from "../components/Button";

export default function OnboardingPage() {
  const { completeOnboarding, user } = useApp();
  const [nickname, setNickname] = useState("");
  const navigate = useNavigate();

  const handleSubmit = () => {
    if (!nickname.trim()) return;
    completeOnboarding(nickname.trim());
    navigate("/home");
  };

  return (
    <div className="flex-1 flex flex-col justify-between px-7 py-14">
      <div>
        <p className="text-[13px] font-bold text-[var(--color-accent)] mb-3">
          {user.loginProvider === "kakao" && "카카오"}
          {user.loginProvider === "naver" && "네이버"}
          {user.loginProvider === "google" && "Google"} 로그인 완료 ✓
        </p>
        <h1 className="text-[26px] font-extrabold text-[var(--color-ink)] leading-tight tracking-tight">
          머물;경에서 사용할
          <br />
          닉네임을 알려주세요
        </h1>
        <p className="text-[13px] text-[var(--color-ink-soft)] mt-3">
          여행 스탬프와 저장한 일정이 이 닉네임으로 기록돼요
        </p>
      </div>

      <div className="space-y-2">
        <input
          autoFocus
          value={nickname}
          onChange={(e) => setNickname(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
          placeholder="닉네임을 입력하세요"
          maxLength={12}
          className="w-full border-b-[2.5px] border-[var(--color-accent)] bg-transparent py-3 text-xl font-bold outline-none placeholder:text-[var(--color-ink-faint)] placeholder:font-medium"
        />
        <p className="text-right text-[11px] text-[var(--color-ink-faint)] font-medium">{nickname.length}/12</p>
      </div>

      <Button variant="accent" fullWidth disabled={!nickname.trim()} onClick={handleSubmit}>
        시작하기
      </Button>
    </div>
  );
}
