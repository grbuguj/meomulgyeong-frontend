import { useMemo, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import TopBar from "../components/TopBar";
import Button from "../components/Button";
import Modal from "../components/Modal";
import { REGION_MAP } from "../data/regions";
import { generateItinerary, regenerateItinerary, regeneratePlaceItem } from "../lib/itinerary";
import { makeTripCompletion } from "../lib/contribution";
import type { CompanionType, Itinerary } from "../types";
import { useApp } from "../store/AppContext";

const CATEGORY_LABEL: Record<string, string> = {
  attraction: "관광",
  food: "식사",
  experience: "체험",
  stay: "휴식",
};

const CATEGORY_COLOR: Record<string, string> = {
  attraction: "bg-[var(--color-mint-soft)] text-[#0c8a67]",
  food: "bg-[var(--color-amber-soft)] text-[#b9700a]",
  experience: "bg-[#efe7fb] text-[#7248c4]",
  stay: "bg-[var(--color-ivory-deep)] text-[var(--color-ink-soft)]",
};

export default function ItineraryPage() {
  const { regionId } = useParams();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const { saveItinerary, savedItineraries, completeTrip, user } = useApp();

  const region = regionId ? REGION_MAP[regionId] : undefined;
  const nights = Number(params.get("nights") ?? 1);
  const companion = (params.get("companion") as CompanionType) ?? "alone";

  const [itin, setItin] = useState<Itinerary>(() =>
    region ? generateItinerary(region, nights, companion) : ({} as Itinerary)
  );
  const [activeDay, setActiveDay] = useState(1);
  const [completeModal, setCompleteModal] = useState(false);
  const [visitors, setVisitors] = useState(1);
  const [stayDays, setStayDays] = useState(itin.days?.length ?? 1);

  const isSaved = useMemo(() => savedItineraries.some((i) => i.id === itin.id), [savedItineraries, itin.id]);

  if (!region) {
    return (
      <div className="p-6">
        <p>지역 정보를 찾을 수 없어요.</p>
      </div>
    );
  }

  const day = itin.days.find((d) => d.day === activeDay) ?? itin.days[0];

  const handleSwap = (itemId: string) => {
    setItin((prev) => ({
      ...prev,
      days: prev.days.map((d) =>
        d.day !== activeDay
          ? d
          : {
              ...d,
              items: d.items.map((it) =>
                it.id === itemId ? regeneratePlaceItem(region, it, Math.random() * 100) : it
              ),
            }
      ),
    }));
  };

  const handleRegenerateAll = () => {
    setItin((prev) => regenerateItinerary(prev, region));
  };

  const handleSave = () => {
    saveItinerary(itin);
  };

  const handleComplete = () => {
    const trip = makeTripCompletion({ ...itin, days: itin.days.slice(0, stayDays) }, visitors);
    completeTrip(trip);
    setCompleteModal(false);
    navigate(`/trip-result/${user.trips.length}`, {
      state: { trip, itinerary: itin },
    });
  };

  return (
    <>
      <TopBar
        title={`${region.shortName} ${nights}박 ${nights + 1}일`}
        onBack
        right={
          <button onClick={handleSave} className="w-9 h-9 rounded-full bg-white card-soft flex items-center justify-center text-base tap">
            {isSaved ? "🔖" : "📑"}
          </button>
        }
      />
      <div className="flex-1 overflow-y-auto pb-28">
        <div className="px-5 pt-3">
          <p className="text-[11px] font-extrabold text-[var(--color-accent)] tracking-wider">AUTO-PLAN</p>
          <h2 className="text-[22px] font-extrabold mt-1 tracking-tight">{region.shortName}을 천천히.</h2>
          <p className="text-[13px] text-[var(--color-ink-soft)] mt-1">{region.identityLine}</p>
        </div>

        <div className="flex gap-2 px-5 mt-4 overflow-x-auto scrollbar-thin pb-1">
          {itin.days.map((d) => (
            <button
              key={d.day}
              onClick={() => setActiveDay(d.day)}
              className={`min-w-[76px] px-3 py-2.5 rounded-2xl text-xs font-bold tap ${
                activeDay === d.day
                  ? "bg-[var(--color-accent)] text-white shadow-[0_6px_16px_-6px_rgba(49,130,246,0.5)]"
                  : "bg-white text-[var(--color-ink-soft)] card-soft"
              }`}
            >
              Day {d.day}
              <br />
              <span className="font-semibold opacity-90">
                {d.weather.temp}° {d.weather.condition}
              </span>
            </button>
          ))}
        </div>

        <div className="px-5 mt-4 space-y-2.5">
          {day.items.map((item) => (
            <div key={item.id} className="bg-white rounded-[20px] card-soft p-3.5 flex gap-3">
              <div className="text-[11px] font-bold text-[var(--color-ink-faint)] w-11 pt-1 shrink-0">{item.time}</div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className={`text-[10px] font-bold px-2 py-1 rounded-full ${CATEGORY_COLOR[item.category]}`}>
                    {CATEGORY_LABEL[item.category]}
                  </span>
                  <p className="text-[14px] font-bold">{item.name}</p>
                </div>
                <p className="text-[12px] text-[var(--color-ink-soft)] mt-1 leading-relaxed">{item.description}</p>
              </div>
              {item.category !== "stay" && (
                <button
                  onClick={() => handleSwap(item.id)}
                  className="text-[11px] font-bold text-[var(--color-accent)] self-start shrink-0 tap"
                >
                  교체 ↻
                </button>
              )}
            </div>
          ))}
        </div>

        <div className="px-5 mt-5">
          <Button variant="secondary" fullWidth onClick={handleRegenerateAll}>
            일정 전체 재생성
          </Button>
        </div>
      </div>

      <div className="sticky bottom-0 bg-[var(--color-ivory)]/95 backdrop-blur p-4">
        <Button variant="accent" fullWidth onClick={() => setCompleteModal(true)}>
          여행 완료
        </Button>
      </div>

      <Modal open={completeModal} onClose={() => setCompleteModal(false)} title="여행을 완료했어요 🎉">
        <div className="space-y-4">
          <div>
            <label className="text-[12px] font-bold text-[var(--color-ink-soft)]">머문 일자 (일)</label>
            <input
              type="number"
              min={1}
              max={itin.days.length}
              value={stayDays}
              onChange={(e) => setStayDays(Number(e.target.value))}
              className="w-full bg-[var(--color-ivory-deep)]/60 rounded-2xl px-4 py-3 mt-1.5 outline-none font-semibold focus:ring-2 focus:ring-[var(--color-accent)]/30"
            />
          </div>
          <div>
            <label className="text-[12px] font-bold text-[var(--color-ink-soft)]">방문 인원 (명)</label>
            <input
              type="number"
              min={1}
              value={visitors}
              onChange={(e) => setVisitors(Number(e.target.value))}
              className="w-full bg-[var(--color-ivory-deep)]/60 rounded-2xl px-4 py-3 mt-1.5 outline-none font-semibold focus:ring-2 focus:ring-[var(--color-accent)]/30"
            />
          </div>
          <Button variant="accent" fullWidth onClick={handleComplete}>
            지역 기여도 확인하기
          </Button>
        </div>
      </Modal>
    </>
  );
}
