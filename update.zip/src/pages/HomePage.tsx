import { useState } from "react";
import { useNavigate } from "react-router-dom";
import TopBar from "../components/TopBar";
import BottomNav from "../components/BottomNav";
import TagChip from "../components/TagChip";
import Button from "../components/Button";
import RegionCard from "../components/RegionCard";
import StepDots from "../components/StepDots";
import { TAGS } from "../data/tags";
import type { CompanionType, Region, TagKey } from "../types";
import { matchRegions } from "../lib/match";
import { useApp } from "../store/AppContext";

const NIGHT_OPTIONS = [1, 2, 3, 4, 5, 6, 7];
const COMPANIONS: { key: CompanionType; label: string; emoji: string }[] = [
  { key: "alone", label: "혼자", emoji: "🧍" },
  { key: "family", label: "가족", emoji: "👨‍👩‍👧" },
  { key: "couple", label: "연인", emoji: "💑" },
  { key: "friend", label: "친구", emoji: "👯" },
];

const STEPS: { key: "tags" | "nights" | "companion" | "result"; index: number }[] = [
  { key: "tags", index: 0 },
  { key: "nights", index: 1 },
  { key: "companion", index: 2 },
  { key: "result", index: 3 },
];

type Step = "tags" | "nights" | "companion" | "result";

export default function HomePage() {
  const { user, setSelection } = useApp();
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>("tags");
  const [tags, setTags] = useState<TagKey[]>([]);
  const [nights, setNights] = useState<number>(2);
  const [customNights, setCustomNights] = useState("");
  const [companion, setCompanion] = useState<CompanionType | null>(null);
  const [results, setResults] = useState<Region[]>([]);

  const stepIndex = STEPS.find((s) => s.key === step)?.index ?? 0;

  const toggleTag = (t: TagKey) => {
    setTags((prev) => {
      if (prev.includes(t)) return prev.filter((x) => x !== t);
      if (prev.length >= 3) return prev; // 최대 3개
      return [...prev, t];
    });
  };

  const runMatch = (finalCompanion: CompanionType) => {
    const matched = matchRegions(tags, finalCompanion, nights);
    setResults(matched);
    setSelection(tags, nights, finalCompanion);
    setStep("result");
  };

  const reset = () => {
    setStep("tags");
    setTags([]);
    setNights(2);
    setCompanion(null);
    setResults([]);
  };

  return (
    <>
      <TopBar
        title={step === "result" ? "추천 지역" : "머물;경"}
        onBack={step !== "tags"}
        right={
          step !== "tags" ? (
            <button onClick={reset} className="text-[11px] font-semibold text-[var(--color-ink-faint)]">
              처음부터
            </button>
          ) : undefined
        }
      />
      <div className="flex-1 overflow-y-auto px-5 pt-1 pb-6">
        {step !== "result" && <StepDots total={3} current={stepIndex} />}

        {step === "tags" && (
          <div className="animate-in">
            <p className="text-[13px] font-semibold text-[var(--color-accent-dark)] mb-2">
              {user.nickname}님, 반가워요 👋
            </p>
            <h2 className="text-[26px] font-extrabold mb-1.5 leading-tight tracking-tight">
              오늘의 취향을
              <br />
              골라주세요
            </h2>
            <p className="text-[13px] text-[var(--color-ink-soft)] mb-5">
              최대 3개까지 선택할 수 있어요 · {tags.length}/3
            </p>
            <div className="flex flex-wrap gap-2">
              {TAGS.map((t) => (
                <TagChip
                  key={t.key}
                  label={t.label}
                  emoji={t.emoji}
                  active={tags.includes(t.key)}
                  disabled={!tags.includes(t.key) && tags.length >= 3}
                  onClick={() => toggleTag(t.key)}
                />
              ))}
            </div>
            <Button
              fullWidth
              variant="accent"
              className="mt-10"
              disabled={tags.length === 0}
              onClick={() => setStep("nights")}
            >
              다음
            </Button>
          </div>
        )}

        {step === "nights" && (
          <div className="animate-in">
            <h2 className="text-[26px] font-extrabold mb-1.5 leading-tight tracking-tight">
              며칠 머무를까요?
            </h2>
            <p className="text-[13px] text-[var(--color-ink-soft)] mb-5">1박부터 7박까지, 더 길게도 가능해요</p>
            <div className="grid grid-cols-4 gap-2">
              {NIGHT_OPTIONS.map((n) => (
                <button
                  key={n}
                  onClick={() => {
                    setNights(n);
                    setCustomNights("");
                  }}
                  className={`py-4 rounded-2xl text-sm font-bold tap ${
                    nights === n && !customNights
                      ? "bg-[var(--color-accent)] text-white shadow-[0_6px_16px_-6px_rgba(49,130,246,0.5)]"
                      : "bg-white text-[var(--color-ink)] card-soft"
                  }`}
                >
                  {n}박
                </button>
              ))}
            </div>
            <div className="mt-5">
              <p className="text-[13px] text-[var(--color-ink-soft)] mb-2 font-medium">7박 이상 머무르시나요?</p>
              <input
                type="number"
                min={8}
                value={customNights}
                onChange={(e) => {
                  setCustomNights(e.target.value);
                  if (e.target.value) setNights(Number(e.target.value));
                }}
                placeholder="직접 입력 (예: 10)"
                className="w-full bg-white rounded-2xl px-4 py-3.5 text-sm outline-none card-soft focus:ring-2 focus:ring-[var(--color-accent)]/30"
              />
            </div>
            <Button fullWidth variant="accent" className="mt-10" onClick={() => setStep("companion")}>
              다음
            </Button>
          </div>
        )}

        {step === "companion" && (
          <div className="animate-in">
            <h2 className="text-[26px] font-extrabold mb-1.5 leading-tight tracking-tight">
              누구와 함께
              <br />
              가시나요?
            </h2>
            <p className="text-[13px] text-[var(--color-ink-soft)] mb-5">동행 형태에 맞춰 지역을 추천해드려요</p>
            <div className="grid grid-cols-2 gap-3">
              {COMPANIONS.map((c) => (
                <button
                  key={c.key}
                  onClick={() => setCompanion(c.key)}
                  className={`py-7 rounded-3xl flex flex-col items-center gap-2 tap ${
                    companion === c.key
                      ? "bg-[var(--color-accent)] text-white shadow-[0_10px_24px_-10px_rgba(49,130,246,0.55)]"
                      : "bg-white card-soft"
                  }`}
                >
                  <span className="text-3xl">{c.emoji}</span>
                  <span className="text-sm font-bold">{c.label}</span>
                </button>
              ))}
            </div>
            <Button
              fullWidth
              variant="accent"
              className="mt-10"
              disabled={!companion}
              onClick={() => companion && runMatch(companion)}
            >
              지역 추천 받기
            </Button>
          </div>
        )}

        {step === "result" && (
          <div className="animate-in space-y-3">
            <h2 className="text-[22px] font-extrabold mb-1 tracking-tight">
              {user.nickname}님을 위한
              <br />
              추천 지역 {results.length}곳
            </h2>
            <p className="text-[13px] text-[var(--color-ink-soft)] mb-3">선택한 조건과 가장 잘 맞는 순서예요</p>
            {results.map((r, idx) => (
              <RegionCard
                key={r.id}
                region={r}
                reason={
                  idx === 0
                    ? "가장 높은 일치도"
                    : `${tags.filter((t) => r.tags.includes(t)).length}개 취향 태그 일치`
                }
                onClick={() => navigate(`/itinerary/${r.id}?nights=${nights}&companion=${companion}`)}
              />
            ))}
          </div>
        )}
      </div>
      <BottomNav />
    </>
  );
}
