import { useLocation, useNavigate } from "react-router-dom";
import TopBar from "../components/TopBar";
import Button from "../components/Button";
import StatTile from "../components/StatTile";
import { REGION_MAP } from "../data/regions";
import { calcContribution } from "../lib/contribution";
import type { Itinerary, TripCompletion } from "../types";
import { useApp } from "../store/AppContext";

export default function TripResultPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useApp();
  const state = location.state as { trip: TripCompletion; itinerary: Itinerary } | undefined;

  if (!state) {
    navigate("/home");
    return null;
  }

  const { trip, itinerary } = state;
  const region = REGION_MAP[trip.regionId];
  const result = calcContribution({ ...itinerary, days: itinerary.days.slice(0, trip.visitedDays) }, trip.visitors);

  return (
    <>
      <TopBar title="이번 여행이 남긴 자국" onBack />
      <div className="flex-1 overflow-y-auto px-5 py-4 pb-8">
        <p className="text-[13px] font-semibold text-[var(--color-accent)]">이번 {region.shortName} 여행으로</p>
        <h2 className="text-[24px] font-extrabold mb-5 tracking-tight">당신이 남긴 자국</h2>

        <div className="grid grid-cols-2 gap-3">
          <StatTile label="방문 지역" value={result.visitedRegions} unit={`/ 15곳`} tone="accent" accent />
          <StatTile label="누적 체류시간" value={result.stayHours} unit="시간" tone="mint" />
          <StatTile label="예상 지역 소비" value={(result.estimatedSpend / 10000).toFixed(1)} unit="만원" tone="amber" />
          <StatTile label="생활인구 산입" value={`+${result.livingPopulationDays}`} unit="일" tone="forest" />
        </div>

        <div className="mt-6 bg-white rounded-[24px] card-soft p-4">
          <p className="text-[14px] font-bold mb-3">경상북도 15개 지역 수집 배지</p>
          <div className="grid grid-cols-5 gap-2">
            {Object.values(REGION_MAP).map((r) => (
              <div
                key={r.id}
                className={`aspect-square rounded-xl flex items-center justify-center text-[10px] font-bold ${
                  user.stamps.includes(r.id)
                    ? "bg-[var(--color-accent)] text-white"
                    : "bg-[var(--color-ivory-deep)] text-[var(--color-ink-faint)]"
                }`}
                title={r.shortName}
              >
                {r.shortName}
              </div>
            ))}
          </div>
          <p className="text-[12px] text-[var(--color-ink-soft)] font-semibold mt-3">
            수집 {user.stamps.length} / 15
          </p>
        </div>

        <p className="text-[11px] text-[var(--color-ink-faint)] mt-4 leading-relaxed">
          예상 소비 금액은 한국관광공사 「국민여행조사」 1인 1일 평균 지출액(숙박·식음료·체험활동)을 기준으로
          산출한 추정값입니다. 생활인구 산입 일수는 행정안전부 「인구감소지역 지원 특별법」 시행령상 체류 기준을
          적용했습니다.
        </p>

        <Button variant="accent" fullWidth className="mt-6" onClick={() => navigate("/my")}>
          마이페이지에서 확인하기
        </Button>
      </div>
    </>
  );
}
