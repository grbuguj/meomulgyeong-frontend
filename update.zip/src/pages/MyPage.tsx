import { useNavigate } from "react-router-dom";
import TopBar from "../components/TopBar";
import BottomNav from "../components/BottomNav";
import RegionArt from "../components/RegionArt";
import { REGIONS, REGION_MAP } from "../data/regions";
import { useApp } from "../store/AppContext";
import { useState } from "react";
import Modal from "../components/Modal";
import Button from "../components/Button";

export default function MyPage() {
  const { user, savedItineraries, removeSavedItinerary, logout, updateNickname } = useApp();
  const navigate = useNavigate();
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [termsOpen, setTermsOpen] = useState(false);
  const [editingNickname, setEditingNickname] = useState(false);
  const [nicknameDraft, setNicknameDraft] = useState(user.nickname);

  const saveNickname = () => {
    if (nicknameDraft.trim()) updateNickname(nicknameDraft.trim());
    setEditingNickname(false);
  };

  return (
    <>
      <TopBar
        title="마이페이지"
        right={
          <button
            onClick={() => setSettingsOpen(true)}
            className="w-9 h-9 rounded-full bg-white card-soft flex items-center justify-center text-base tap"
          >
            ⚙️
          </button>
        }
      />
      <div className="flex-1 overflow-y-auto pb-4">
        <div className="px-5 pt-3 flex items-center gap-3.5">
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center text-3xl card-soft"
            style={{ background: "linear-gradient(150deg, var(--color-accent-soft), #fff)" }}
          >
            🙂
          </div>
          <div>
            <p className="font-extrabold text-[18px] text-[var(--color-ink)] tracking-tight">{user.nickname}님</p>
            <p className="text-[12.5px] text-[var(--color-ink-soft)] font-medium mt-0.5">
              완료한 여행 {user.trips.length}회 · 배지 {user.stamps.length}/15
            </p>
          </div>
        </div>

        <div className="px-5 mt-6">
          <p className="text-[14px] font-bold mb-2.5">경상북도 15개 지역 스탬프</p>
          <div className="grid grid-cols-5 gap-2">
            {REGIONS.map((r) => (
              <button
                key={r.id}
                onClick={() => navigate(`/region/${r.id}`)}
                className={`aspect-square rounded-xl flex items-center justify-center text-[10px] font-bold tap ${
                  user.stamps.includes(r.id)
                    ? "bg-[var(--color-accent)] text-white shadow-[0_4px_12px_-4px_rgba(49,130,246,0.5)]"
                    : "bg-[var(--color-ivory-deep)] text-[var(--color-ink-faint)]"
                }`}
              >
                {r.shortName}
              </button>
            ))}
          </div>
        </div>

        <div className="px-5 mt-6">
          <p className="text-[14px] font-bold mb-2.5">저장한 일정 ({savedItineraries.length})</p>
          {savedItineraries.length === 0 && (
            <p className="text-[12.5px] text-[var(--color-ink-soft)] bg-white rounded-2xl p-4 card-soft leading-relaxed">
              아직 저장한 일정이 없어요. 지역 추천에서 마음에 드는 일정을 책갈피 해보세요.
            </p>
          )}
          <div className="space-y-2.5">
            {savedItineraries.map((itin) => {
              const region = REGION_MAP[itin.regionId];
              return (
                <div key={itin.id} className="bg-white rounded-[20px] card-soft overflow-hidden flex items-stretch">
                  <RegionArt region={region} className="w-20" label={false} />
                  <div className="flex-1 p-3 flex items-center justify-between">
                    <div>
                      <p className="text-[13.5px] font-bold">{region.name}</p>
                      <p className="text-[11.5px] text-[var(--color-ink-soft)] font-medium">
                        {itin.nights}박 {itin.nights + 1}일
                      </p>
                    </div>
                    <div className="flex gap-3">
                      <button
                        onClick={() =>
                          navigate(`/itinerary/${itin.regionId}?nights=${itin.nights}&companion=${itin.companion}`)
                        }
                        className="text-[12px] text-[var(--color-accent)] font-bold"
                      >
                        보기
                      </button>
                      <button
                        onClick={() => removeSavedItinerary(itin.id)}
                        className="text-[12px] text-[var(--color-ink-faint)] font-bold"
                      >
                        삭제
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {user.trips.length > 0 && (
          <div className="px-5 mt-6">
            <p className="text-[14px] font-bold mb-2.5">완료한 여행 기록</p>
            <div className="space-y-2">
              {user.trips.map((t, idx) => {
                const region = REGION_MAP[t.regionId];
                return (
                  <div key={idx} className="bg-white rounded-2xl card-soft p-3.5 flex justify-between items-center">
                    <div>
                      <p className="text-[13.5px] font-bold">{region.name}</p>
                      <p className="text-[11.5px] text-[var(--color-ink-soft)] font-medium">
                        {t.visitedDays}일 체류 · {t.visitors}명
                      </p>
                    </div>
                    <span className="text-[11px] text-[var(--color-ink-faint)] font-semibold">
                      {new Date(t.completedAt).toLocaleDateString("ko-KR")}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
      <BottomNav />

      <Modal
        open={settingsOpen}
        onClose={() => {
          setSettingsOpen(false);
          setEditingNickname(false);
        }}
        title="설정"
      >
        <div className="space-y-1">
          <div className="flex items-center justify-between py-3 border-b border-[var(--color-line)]">
            <span className="text-[13px] font-semibold text-[var(--color-ink-soft)]">닉네임</span>
            {editingNickname ? (
              <div className="flex items-center gap-2">
                <input
                  autoFocus
                  value={nicknameDraft}
                  onChange={(e) => setNicknameDraft(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && saveNickname()}
                  maxLength={12}
                  className="text-right text-[14px] font-bold bg-[var(--color-ivory-deep)]/60 rounded-lg px-2 py-1 outline-none w-28"
                />
                <button onClick={saveNickname} className="text-[12px] font-bold text-[var(--color-accent)]">
                  완료
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  setNicknameDraft(user.nickname);
                  setEditingNickname(true);
                }}
                className="flex items-center gap-1.5 text-[14px] font-bold"
              >
                {user.nickname} <span className="text-[11px] text-[var(--color-ink-faint)]">✎ 수정</span>
              </button>
            )}
          </div>
          <div className="flex justify-between text-[13px] py-3 border-b border-[var(--color-line)]">
            <span className="font-semibold text-[var(--color-ink-soft)]">로그인 방식</span>
            <span className="font-bold capitalize">{user.loginProvider}</span>
          </div>
          <button
            onClick={() => setTermsOpen(true)}
            className="w-full flex justify-between text-[13px] py-3 border-b border-[var(--color-line)]"
          >
            <span className="font-semibold text-[var(--color-ink-soft)]">이용약관 · 개인정보처리방침</span>
            <span className="text-[var(--color-ink-faint)]">›</span>
          </button>
          <div className="flex justify-between text-[13px] py-3 border-b border-[var(--color-line)]">
            <span className="font-semibold text-[var(--color-ink-soft)]">버전</span>
            <span className="font-bold">v0.1.0 (MVP)</span>
          </div>
          <Button variant="secondary" fullWidth className="mt-4" onClick={logout}>
            로그아웃
          </Button>
        </div>
      </Modal>

      <Modal open={termsOpen} onClose={() => setTermsOpen(false)} title="이용약관 · 개인정보처리방침">
        <div className="text-[12.5px] text-[var(--color-ink-soft)] leading-relaxed space-y-3">
          <p>
            본 서비스는 2026 관광데이터 활용 공모전 제출을 위한 MVP 데모입니다. 실제 약관 문서는 서비스 정식
            출시 시점에 법무 검토를 거쳐 게시됩니다.
          </p>
          <p>수집 항목: 소셜 로그인 식별정보, 닉네임, 여행 일정·완료 기록(방문 지역, 체류일수, 인원)</p>
          <p>이용 목적: 지역 추천 정확도 개선, 지역 기여도 산출, 서비스 품질 개선</p>
        </div>
      </Modal>
    </>
  );
}
