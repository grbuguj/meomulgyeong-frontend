import { useNavigate, useParams } from "react-router-dom";
import TopBar from "../components/TopBar";
import RegionArt from "../components/RegionArt";
import Button from "../components/Button";
import { REGION_MAP } from "../data/regions";
import { TAG_MAP } from "../data/tags";
import { useApp } from "../store/AppContext";

export default function RegionDetailPage() {
  const { regionId } = useParams();
  const navigate = useNavigate();
  const { user } = useApp();
  const region = regionId ? REGION_MAP[regionId] : undefined;

  if (!region) return <div className="p-6">지역을 찾을 수 없어요.</div>;

  return (
    <>
      <TopBar title={region.name} onBack />
      <div className="flex-1 overflow-y-auto pb-24">
        <div className="px-4 pt-1">
          <RegionArt region={region} className="h-44 rounded-[24px]" />
        </div>
        <div className="px-5 py-4">
          <div className="flex items-center gap-2 flex-wrap mb-2.5">
            {user.stamps.includes(region.id) && (
              <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-[var(--color-mint)] text-white">
                ✓ 방문 완료
              </span>
            )}
            {region.isVerifiedHub && (
              <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-[var(--color-amber-soft)] text-[#b9700a]">
                대표 검증 거점
              </span>
            )}
          </div>
          <h2 className="text-[20px] font-extrabold leading-snug tracking-tight">{region.identityLine}</h2>
          <p className="text-[13.5px] text-[var(--color-ink-soft)] mt-3 leading-relaxed">{region.description}</p>

          <div className="mt-4 flex gap-1.5 flex-wrap">
            {region.tags.map((t) => (
              <span
                key={t}
                className="text-[12px] font-semibold px-3 py-1.5 rounded-full bg-[var(--color-ivory-deep)] text-[var(--color-ink-soft)]"
              >
                {TAG_MAP[t]?.emoji} {TAG_MAP[t]?.label}
              </span>
            ))}
          </div>

          <div className="mt-6">
            <p className="text-[14px] font-bold mb-2.5">대표 관광 포인트</p>
            <div className="flex flex-wrap gap-2">
              {region.representativeSpots.map((s) => (
                <span key={s} className="text-[12.5px] font-semibold px-3.5 py-2 rounded-2xl bg-white card-soft">
                  {s}
                </span>
              ))}
            </div>
          </div>

          <div className="mt-6">
            <p className="text-[14px] font-bold mb-1">여행 성격</p>
            <p className="text-[13.5px] text-[var(--color-ink-soft)]">{region.travelStyle}</p>
          </div>

          <div
            className="mt-6 rounded-[22px] p-4"
            style={{ background: "linear-gradient(150deg, var(--color-accent-soft), #ffffff)" }}
          >
            <p className="text-[13px] font-bold text-[var(--color-accent-dark)] mb-1.5">🗝️ 현지인 꿀정보</p>
            <p className="text-[13.5px] text-[var(--color-ink-soft)] leading-relaxed">{region.localTip}</p>
          </div>
        </div>
      </div>

      <div className="sticky bottom-0 bg-[var(--color-ivory)]/95 backdrop-blur p-4">
        <Button variant="accent" fullWidth onClick={() => navigate(`/itinerary/${region.id}?nights=2&companion=alone`)}>
          이 지역으로 일정 만들기
        </Button>
      </div>
    </>
  );
}
