import type { Region } from "../types";

/**
 * 실제 관광 사진 대신 지역별 팔레트를 활용한 절차적 그라디언트 아트.
 * (제안서 목업의 아이보리·차분한 톤 계승, 저작권 이슈 없는 대체 비주얼)
 */
export default function RegionArt({
  region,
  className = "",
  label = true,
}: {
  region: Region;
  className?: string;
  label?: boolean;
}) {
  const [c1, c2] = region.heroPalette;
  return (
    <div
      className={`relative overflow-hidden flex items-end ${className}`}
      style={{
        background: `linear-gradient(150deg, ${c1} 0%, ${c2} 100%)`,
      }}
    >
      <svg
        className="absolute inset-0 w-full h-full opacity-25"
        viewBox="0 0 200 100"
        preserveAspectRatio="none"
      >
        <path d="M0 70 L30 40 L55 60 L85 25 L120 55 L150 30 L200 60 L200 100 L0 100 Z" fill="white" />
      </svg>
      {label && (
        <div className="relative z-10 p-3 text-white">
          <p className="text-xs opacity-80 tracking-wide">경상북도</p>
          <p className="text-lg font-semibold">{region.shortName}</p>
        </div>
      )}
    </div>
  );
}
