import type { ReactNode } from "react";

export default function Modal({
  open,
  onClose,
  children,
  title,
}: {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  title?: string;
}) {
  if (!open) return null;
  return (
    <div
      className="absolute inset-0 z-30 flex items-end justify-center backdrop-blur-[2px]"
      style={{ background: "rgba(20,20,20,0.45)" }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full bg-white rounded-t-[28px] p-5 pb-8 max-h-[85%] overflow-y-auto"
        style={{ animation: "slideUp 0.24s cubic-bezier(0.16,1,0.3,1)" }}
      >
        <div className="w-10 h-1.5 rounded-full bg-[var(--color-line)] mx-auto mb-4" />
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-[17px] font-bold">{title}</h2>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-[var(--color-ivory-deep)] text-[var(--color-ink-soft)] text-base leading-none flex items-center justify-center"
          >
            ×
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
