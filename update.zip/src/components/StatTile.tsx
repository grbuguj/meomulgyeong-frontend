export default function StatTile({
  label,
  value,
  unit,
  accent,
  tone = "accent",
}: {
  label: string;
  value: string | number;
  unit?: string;
  accent?: boolean;
  tone?: "accent" | "mint" | "amber" | "forest";
}) {
  const tones: Record<string, { bg: string; text: string; solid: string }> = {
    accent: { bg: "var(--color-accent-soft)", text: "var(--color-accent-dark)", solid: "var(--color-accent)" },
    mint: { bg: "var(--color-mint-soft)", text: "#0c8a67", solid: "var(--color-mint)" },
    amber: { bg: "var(--color-amber-soft)", text: "#b9700a", solid: "var(--color-amber)" },
    forest: { bg: "#eaf0ec", text: "var(--color-forest-dark)", solid: "var(--color-forest)" },
  };
  const t = tones[tone];

  return (
    <div
      className="rounded-3xl p-4 card-soft"
      style={{
        background: accent ? t.solid : t.bg,
        color: accent ? "#fff" : "var(--color-ink)",
      }}
    >
      <p
        className="text-[12px] font-medium"
        style={{ color: accent ? "rgba(255,255,255,0.85)" : t.text }}
      >
        {label}
      </p>
      <p className="text-[26px] font-extrabold mt-1 tracking-tight">
        {value}
        {unit && <span className="text-[13px] font-semibold ml-1">{unit}</span>}
      </p>
    </div>
  );
}
