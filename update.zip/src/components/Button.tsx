import type { ButtonHTMLAttributes } from "react";

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost" | "accent";
  fullWidth?: boolean;
}

export default function Button({
  variant = "primary",
  fullWidth,
  className = "",
  children,
  ...rest
}: Props) {
  const base =
    "rounded-2xl px-5 py-3.5 text-[15px] font-bold transition-all tap disabled:opacity-35 disabled:active:scale-100";
  const styles = {
    primary: "bg-[var(--color-forest)] text-white shadow-[0_8px_20px_-8px_rgba(63,94,74,0.55)] hover:bg-[var(--color-forest-dark)]",
    accent: "bg-[var(--color-accent)] text-white shadow-[0_8px_20px_-8px_rgba(49,130,246,0.55)] hover:bg-[var(--color-accent-dark)]",
    secondary: "bg-white text-[var(--color-forest)] border border-[var(--color-line)] card-soft",
    ghost: "bg-transparent text-[var(--color-ink-soft)]",
  }[variant];
  return (
    <button className={`${base} ${styles} ${fullWidth ? "w-full" : ""} ${className}`} {...rest}>
      {children}
    </button>
  );
}
