import type { ReactNode } from "react";

/**
 * 모바일 앱처럼 보이도록 감싸는 프레임. 데스크톱 브라우저에서도
 * 목업 UI와 동일한 세로형 카드 레이아웃을 유지하기 위함.
 */
export default function PhoneShell({ children }: { children: ReactNode }) {
  return (
    <div
      className="min-h-screen w-full flex items-center justify-center py-6 px-2"
      style={{
        background: "radial-gradient(circle at 50% 0%, #f0ecdf 0%, #e3ddc9 100%)",
      }}
    >
      <div className="w-full max-w-[420px] min-h-[780px] bg-[var(--color-ivory)] rounded-[32px] overflow-hidden flex flex-col relative border border-white/60 card-soft-lg">
        {children}
      </div>
    </div>
  );
}
