import { NavLink } from "react-router-dom";

const NAV_ITEMS = [
  { to: "/home", label: "홈", icon: "🏠" },
  { to: "/explore", label: "둘러보기", icon: "🧭" },
  { to: "/my", label: "마이페이지", icon: "👤" },
];

export default function BottomNav() {
  return (
    <nav className="sticky bottom-0 z-20 bg-white/95 backdrop-blur border-t border-[var(--color-line)] flex justify-around py-2.5 px-3">
      {NAV_ITEMS.map((item) => (
        <NavLink
          key={item.to}
          to={item.to}
          className={({ isActive }) =>
            `flex flex-col items-center gap-0.5 px-5 py-1.5 rounded-2xl text-[11px] font-semibold tap ${
              isActive
                ? "text-[var(--color-accent)] bg-[var(--color-accent-soft)]"
                : "text-[var(--color-ink-faint)]"
            }`
          }
        >
          <span className="text-lg leading-none">{item.icon}</span>
          {item.label}
        </NavLink>
      ))}
    </nav>
  );
}
