import { useNavigate } from "react-router-dom";
import type { Region } from "../types";
import RegionArt from "./RegionArt";
import { TAG_MAP } from "../data/tags";

export default function RegionCard({
  region,
  reason,
  onClick,
}: {
  region: Region;
  reason?: string;
  onClick?: () => void;
}) {
  const navigate = useNavigate();
  return (
    <button
      onClick={onClick ?? (() => navigate(`/region/${region.id}`))}
      className="w-full text-left bg-white rounded-[24px] overflow-hidden card-soft tap"
    >
      <RegionArt region={region} className="h-32" />
      <div className="p-4">
        <div className="flex items-center justify-between">
          <p className="font-bold text-[16px] text-[var(--color-ink)]">{region.name}</p>
          {region.isVerifiedHub && (
            <span className="text-[10px] font-bold px-2 py-1 rounded-full bg-[var(--color-amber-soft)] text-[#b9700a]">
              대표 거점
            </span>
          )}
        </div>
        <p className="text-[13px] text-[var(--color-ink-soft)] mt-1 leading-relaxed">{region.identityLine}</p>
        {reason && (
          <p className="text-[12px] font-semibold text-[var(--color-accent-dark)] mt-2.5 bg-[var(--color-accent-soft)] rounded-xl px-2.5 py-1.5 inline-block">
            ✓ {reason}
          </p>
        )}
        <div className="flex gap-1.5 mt-2.5 flex-wrap">
          {region.tags.map((t) => (
            <span
              key={t}
              className="text-[11px] font-medium px-2.5 py-1 rounded-full bg-[var(--color-ivory-deep)] text-[var(--color-ink-soft)]"
            >
              {TAG_MAP[t]?.emoji} {TAG_MAP[t]?.label}
            </span>
          ))}
        </div>
      </div>
    </button>
  );
}
