export default function StepDots({ total, current }: { total: number; current: number }) {
  return (
    <div className="flex gap-1.5 mb-5">
      {Array.from({ length: total }).map((_, i) => (
        <div
          key={i}
          className="h-1.5 rounded-full flex-1 transition-all duration-300"
          style={{
            background: i <= current ? "var(--color-accent)" : "var(--color-line)",
          }}
        />
      ))}
    </div>
  );
}
