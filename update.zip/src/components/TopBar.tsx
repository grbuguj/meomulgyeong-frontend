import { useNavigate } from "react-router-dom";

export default function TopBar({
  title,
  onBack,
  right,
}: {
  title: string;
  onBack?: boolean;
  right?: React.ReactNode;
}) {
  const navigate = useNavigate();
  return (
    <div className="flex items-center justify-between px-4 py-3.5 bg-[var(--color-ivory)]/95 backdrop-blur sticky top-0 z-10">
      <div className="w-9">
        {onBack && (
          <button
            onClick={() => navigate(-1)}
            className="w-8 h-8 rounded-full bg-white card-soft flex items-center justify-center text-[15px] text-[var(--color-ink)] tap"
            aria-label="뒤로가기"
          >
            ←
          </button>
        )}
      </div>
      <h1 className="text-[16px] font-bold text-[var(--color-ink)] tracking-tight">{title}</h1>
      <div className="w-9 flex justify-end">{right}</div>
    </div>
  );
}
