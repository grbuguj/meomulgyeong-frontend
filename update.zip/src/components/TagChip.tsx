export default function TagChip({
  label,
  emoji,
  active,
  disabled,
  onClick,
}: {
  label: string;
  emoji?: string;
  active: boolean;
  disabled?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={`px-4 py-2.5 rounded-2xl text-sm font-semibold tap whitespace-nowrap ${
        active
          ? "bg-[var(--color-accent)] text-white shadow-[0_6px_16px_-6px_rgba(49,130,246,0.5)]"
          : "bg-white text-[var(--color-ink-soft)] border border-[var(--color-line)]"
      } ${disabled ? "opacity-35 cursor-not-allowed" : ""}`}
    >
      {emoji && <span className="mr-1.5">{emoji}</span>}
      {label}
    </button>
  );
}
